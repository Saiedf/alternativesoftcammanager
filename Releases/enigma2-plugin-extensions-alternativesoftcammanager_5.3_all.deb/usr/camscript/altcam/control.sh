# Shared POSIX shell implementation, sourced by generated cam launchers.
# Install the entire camscript directory, including its altcam directory.
umask 077
BIN_DIR=${ALT_SOFTCAM_BIN_DIR:-/usr/bin}
RUN_DIR=${ALT_SOFTCAM_RUN_DIR:-/tmp/altsoftcam}
BIN=$BIN_DIR/$CAM
PID_FILE=$RUN_DIR/$CAM.pid
LOG_FILE=$RUN_DIR/$CAM.log
LOCK_DIR=$RUN_DIR/operation.lock
LOCK_OWNED=0

error() { printf '%s: %s\n' "$CAM" "$*" >&2; }

running() {
    PIDS=$(pidof "$CAM" 2>/dev/null)
    probe=$?
    case "$probe" in
        0) case "$PIDS" in ''|*[!0-9\ ]*) return 4 ;; esac; return 0 ;;
        1) return 3 ;;
        *) return 4 ;;
    esac
}

release_lock() {
    if [ "$LOCK_OWNED" = 1 ]; then
        rm -f "$LOCK_DIR/pid"
        rmdir "$LOCK_DIR" 2>/dev/null || :
        LOCK_OWNED=0
    fi
}

lock_owner_alive() {
    # True only when the pid in the lock belongs to a live cam operation of ours.
    pid=$1
    case "$pid" in ''|*[!0-9]*|0|1) return 1 ;; esac
    kill -0 "$pid" 2>/dev/null || return 1
    if [ -r "/proc/$pid/cmdline" ]; then
        # The pid may have been reused by an unrelated process after a crash.
        case "$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)" in
            *camscript*|*altcam*|*_cam.sh*|*control.sh*|*generic.sh*) return 0 ;;
            *) return 1 ;;
        esac
    fi
    return 0
}

acquire_lock() {
    [ -d "$RUN_DIR" ] || mkdir -p "$RUN_DIR" || return 1
    waited=0
    removed=0
    while ! mkdir "$LOCK_DIR" 2>/dev/null; do
        owner=''
        [ ! -r "$LOCK_DIR/pid" ] || read -r owner < "$LOCK_DIR/pid"
        if lock_owner_alive "$owner"; then
            error 'Another cam operation is in progress'
            return 1
        fi
        # No live owner. A lock without any pid may belong to an operation that is just starting,
        # so wait up to two seconds; a dead owner is certain. Either way the lock (and a stale
        # recovery.lock) is then left over from a killed run and is removed, so changing the cam
        # never needs a reboot.
        if [ -z "$owner" ] && [ "$waited" -lt 2 ]; then
            waited=$((waited + 1))
            sleep 1
            continue
        fi
        removed=$((removed + 1))
        [ "$removed" -le 3 ] || { error 'Cannot take the cam operation lock'; return 1; }
        rm -f "$LOCK_DIR/pid"
        rmdir "$LOCK_DIR" 2>/dev/null || :
        rmdir "$RUN_DIR/recovery.lock" 2>/dev/null || :
    done
    LOCK_OWNED=1
    trap 'release_lock' 0
    trap 'exit 130' INT
    trap 'exit 143' TERM
    printf '%s\n' "$$" > "$LOCK_DIR/pid" || { release_lock; return 1; }
}

validate_platform() {
    machine=$(uname -m) || return 1
    case "$CAM_ARCH:$machine" in
        arm32:arm*|arm32:aarch64|arm32:arm64|arm64:aarch64|arm64:arm64) : ;;
        mips:mips*|sh4:sh4*|x86:i?86|x86:x86_64|x86_64:x86_64) : ;;
        native:*) : ;;  # unknown CPU type: the kernel decides
        *) error "Binary architecture $CAM_ARCH is incompatible with $machine"; return 1 ;;
    esac
    if [ -n "$CAM_INTERPRETER" ] && [ ! -f "$CAM_INTERPRETER" ]; then
        error "Required ELF loader is missing: $CAM_INTERPRETER"
        return 1
    fi
    [ -f "$BIN" ] || { error "Binary not found: $BIN"; return 1; }
    [ -x "$BIN" ] || chmod u+x "$BIN" || return 1
}

config_directory() {
    CONFIG_DIR=${ALT_SOFTCAM_CONFIG_DIR-}
    if [ -z "$CONFIG_DIR" ] && [ -r /etc/enigma2/settings ]; then
        CONFIG_DIR=$(sed -n 's/^config.plugins.AltSoftcam.camconfig=//p' /etc/enigma2/settings | tail -n 1)
    fi
    if [ -z "$CONFIG_DIR" ]; then
        CONFIG_DIR=/etc/tuxbox/config
        case "$CAM_FAMILY" in oscam) conf=oscam.conf ;; ncam) conf=ncam.conf ;; esac
        if [ ! -f "$CONFIG_DIR/$conf" ] && [ -f "/var/keys/$conf" ]; then
            CONFIG_DIR=/var/keys
        fi
    fi
    case "$CONFIG_DIR" in /*) : ;; *) error 'Configuration directory must be absolute'; return 1 ;; esac
    [ -d "$CONFIG_DIR" ] || { error "Configuration directory not found: $CONFIG_DIR"; return 1; }
}

other_cam_running() {
    # The list is built from what is installed, so it is right on every receiver:
    # every oscam/ncam/cccam binary in the bin folder, plus the optional altcam/cams.list.
    set --
    for file in "$BIN_DIR"/*; do
        [ -f "$file" ] || continue
        name=${file##*/}
        case "$name" in
            *.conf|*.cfg|*.txt|*.bak|*.old|*.tmp|*.log|*.list|*.xml|*.sh|*.py|*.pyc|*.so|*.key|*.server|*.user) continue ;;
        esac
        lower=$(printf '%s' "$name" | tr 'A-Z' 'a-z')
        case "$lower" in
            oscam*|ncam*|cccam*) [ "$name" = "$CAM" ] || set -- "$@" "$name" ;;
        esac
    done
    if [ -r "$SCRIPT_DIR/altcam/cams.list" ]; then
        while IFS= read -r name; do
            [ -n "$name" ] && [ "$name" != "$CAM" ] && set -- "$@" "$name"
        done < "$SCRIPT_DIR/altcam/cams.list"
    fi
    [ "$#" -gt 0 ] || return 1
    pidof "$@" >/dev/null 2>&1
}

cam_start() {
    running
    state=$?
    case "$state" in
        0) printf '%s is already running\n' "$CAM"; return 0 ;;
        3) : ;;
        *) error 'Cannot determine process status'; return 1 ;;
    esac
    other_cam_running
    state=$?
    case "$state" in
        0) error 'Another listed cam is running; stop it before starting this cam'; return 1 ;;
        1) : ;;
        *) error 'Cannot check other cam processes'; return 1 ;;
    esac
    validate_platform || return 1
    : > "$LOG_FILE" 2>/dev/null   # a fresh log for every start, so the reason shown below is current
    case "$CAM_FAMILY" in
        cccam) "$BIN" </dev/null >>"$LOG_FILE" 2>&1 & ;;
        oscam|ncam)
            config_directory || return 1
            "$BIN" -b -c "$CONFIG_DIR" -B "$PID_FILE" -r 0 </dev/null >>"$LOG_FILE" 2>&1 &
            ;;
        *) error 'Unsupported cam family'; return 1 ;;
    esac
    attempt=0
    while [ "$attempt" -lt 5 ]; do
        sleep 1
        running
        state=$?
        case "$state" in
            0) printf '%s started\n' "$CAM"; return 0 ;;
            3) : ;;
            *) error 'Cannot verify started process'; return 1 ;;
        esac
        attempt=$((attempt + 1))
    done
    error "Start failed or timed out; see $LOG_FILE"
    # The cam's own last words (wrong CPU type, missing library, bad option ...) are the real reason.
    [ -r "$LOG_FILE" ] && tail -n 3 "$LOG_FILE" >&2
    return 1
}

cam_stop() {
    running
    state=$?
    case "$state" in
        3) printf '%s is already stopped\n' "$CAM"; return 0 ;;
        0) : ;;
        *) error 'Cannot determine process status'; return 1 ;;
    esac
    # PIDS is validated as digits and spaces; intentional splitting handles all PIDs.
    kill -TERM $PIDS 2>/dev/null || { error 'Cannot signal cam process'; return 1; }
    attempt=0
    while [ "$attempt" -lt 5 ]; do
        running
        state=$?
        case "$state" in
            3) rm -f "$PID_FILE"; printf '%s stopped\n' "$CAM"; return 0 ;;
            0) : ;;
            *) error 'Cannot verify stopped process'; return 1 ;;
        esac
        sleep 1
        attempt=$((attempt + 1))
    done
    # It ignored the polite request: end it by force so that changing the cam never needs a reboot.
    kill -KILL $PIDS 2>/dev/null
    attempt=0
    while [ "$attempt" -lt 3 ]; do
        sleep 1
        running
        state=$?
        if [ "$state" -eq 3 ]; then
            rm -f "$PID_FILE"
            printf '%s was stopped by force\n' "$CAM"
            return 0
        fi
        attempt=$((attempt + 1))
    done
    error 'Stop timed out; restart was cancelled'
    return 1
}

for utility in pidof mkdir rmdir rm sleep uname; do
    command -v "$utility" >/dev/null 2>&1 || { error "Missing command: $utility"; exit 1; }
done

case "${1:-status}" in
    status)
        running; state=$?
        case "$state" in
            0) printf '%s is running\n' "$CAM" ;;
            3) printf '%s is stopped\n' "$CAM" ;;
            *) error 'Cannot determine process status' ;;
        esac
        exit "$state"
        ;;
    start|cam_up|cam_startup) action=start ;;
    stop|cam_down) action=stop ;;
    restart|cam_res) action=restart ;;
    *) error 'Usage: start|stop|restart|status|cam_up|cam_down|cam_startup|cam_res'; exit 2 ;;
esac

acquire_lock || exit 1
case "$action" in
    start) cam_start ;;
    stop) cam_stop ;;
    restart) cam_stop && cam_start ;;
esac
exit $?
