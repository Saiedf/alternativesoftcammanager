"""Keeps the per-cam launchers and the cam list in step with the cams installed on the receiver.

This module has no Enigma2 dependency. It is used in two places:
  * the plugin calls sync_launchers() every time it is opened or started;
  * the package post-install script runs it directly, so the launchers already exist
    in the script folder right after the installation:
        python Launchers.py [cam folder] [script folder]
Python 2.7 and 3 compatible.
"""
from __future__ import print_function
import os
import struct
import sys

FAMILY_PREFIXES = ("oscam", "ncam", "cccam")
NOT_A_CAM = (".conf", ".cfg", ".txt", ".bak", ".old", ".tmp", ".log", ".list", ".xml", ".sh",
             ".py", ".pyc", ".so", ".key", ".server", ".user")
TAG = "[Alternative SoftCam Manager]"
# Launchers written by this module (and the ones shipped before) carry this line; a script
# without it was written by the user and is never changed or removed.
MARKER = "# Launcher for the adjacent bin package."

LAUNCHER_TEMPLATE = MARKER + """
OSD='%(cam)s'
CAM='%(cam)s'
CAM_FAMILY='%(family)s'
CAM_ARCH='%(arch)s'
CAM_INTERPRETER='%(interpreter)s'
SCRIPT_DIR=$(CDPATH= cd -P "$(dirname "$0")" && pwd) || exit 1
if [ ! -r "$SCRIPT_DIR/altcam/control.sh" ]; then
    echo "Missing altcam/control.sh; install the entire camscript directory" >&2
    exit 1
fi
. "$SCRIPT_DIR/altcam/control.sh"
"""
LAUNCHER_TEMPLATE = "#!/bin/sh\n" + LAUNCHER_TEMPLATE


def _text(value):
    return value.decode("utf-8", "replace") if isinstance(value, bytes) else value


def family_name(cam):
    """oscam, ncam or cccam judged from the binary name, else None."""
    lowered = cam.lower()
    for prefix in FAMILY_PREFIXES:
        if lowered.startswith(prefix):
            return prefix
    return None


def valid_name(cam):
    """Plain file-name characters only: the name ends up in paths and shell commands."""
    return bool(cam) and not cam.startswith(("-", ".")) and \
        all(ch.isalnum() or ch in "._+-" for ch in cam)


def is_cam_name(cam):
    return valid_name(cam) and family_name(cam) is not None and not cam.lower().endswith(NOT_A_CAM)


def elf_info(path):
    """(arch, loader) read from the ELF header of a cam binary: arm32, arm64, mips, sh4, x86, x86_64 or native."""
    with open(path, "rb") as handle:
        head = handle.read(4096)
        data = bytearray(head)
        if len(data) < 52 or data[:4] != bytearray(b"\x7fELF"):
            raise ValueError("not an ELF binary (or truncated)")
        is64 = data[4] == 2
        end = "<" if data[5] == 1 else ">"
        machine = struct.unpack(end + "H", bytes(head[18:20]))[0]
        if is64:
            phoff = struct.unpack(end + "Q", bytes(head[32:40]))[0]
            phentsize, phnum = struct.unpack(end + "HH", bytes(head[54:58]))
        else:
            phoff = struct.unpack(end + "I", bytes(head[28:32]))[0]
            phentsize, phnum = struct.unpack(end + "HH", bytes(head[42:46]))
        loader = ""
        for index in range(min(phnum, 64)):
            handle.seek(phoff + index * phentsize)
            entry = handle.read(56 if is64 else 32)
            if is64:
                kind, _flags, off, _va, _pa, size = struct.unpack(end + "IIQQQQ", bytes(entry[:40]))
            else:
                kind, off, _va, _pa, size = struct.unpack(end + "IIIII", bytes(entry[:20]))
            if kind == 3 and 0 < size < 256:  # PT_INTERP: the dynamic loader path
                handle.seek(off)
                loader = _text(handle.read(size).split(b"\0")[0])
    return {40: "arm32", 183: "arm64", 8: "mips", 42: "sh4", 3: "x86", 62: "x86_64"}.get(machine, "native"), loader


def _write_atomic(path, text, mode):
    temporary = path + ".tmp"
    try:
        with open(temporary, "wb") as handle:
            handle.write(text.encode("utf-8"))
        os.chmod(temporary, mode)
        # os.replace (Python 3) also overwrites on Windows; on Linux rename is already atomic.
        getattr(os, "replace", os.rename)(temporary, path)
        return True
    except (IOError, OSError) as error:
        print(TAG, "Cannot write", path, ":", error)
        try:
            os.remove(temporary)
        except OSError:
            pass
        return False


def _read(path):
    try:
        with open(path, "rb") as handle:
            return _text(handle.read(8192))
    except (IOError, OSError):
        return None


def write_cams_list(path, names):
    """Write the installed cams, one per line, replacing the file only when its content changes."""
    text = "".join(name + "\n" for name in names)
    if _read(path) != text:
        _write_atomic(path, text, 0o644)


def sync_launchers(camdir, scriptdir):
    """Make <cam>_cam.sh in scriptdir match the cam binaries found in camdir.

    * a launcher is created for every cam that has none;
    * a launcher written by this module is rewritten when the binary changed (CPU type or loader);
    * a launcher written by this module whose binary is gone is removed;
    * a script that is not ours is never touched;
    * altcam/cams.list is rewritten with the cams installed on this receiver.

    Returns (created, updated, removed) as lists of cam names.
    """
    created, updated, removed = [], [], []
    if not os.path.isfile(os.path.join(scriptdir, "altcam", "control.sh")) or not os.path.isdir(camdir):
        return created, updated, removed
    installed = []
    for cam in sorted(os.listdir(camdir), key=lambda name: name.lower()):
        path = os.path.join(camdir, cam)
        if not (is_cam_name(cam) and os.path.isfile(path)):
            continue
        target = os.path.join(scriptdir, cam + "_cam.sh")
        current = _read(target)
        if current is not None and MARKER not in current:
            installed.append(cam)          # the user's own script: keep it as it is
            continue
        try:
            arch, loader = elf_info(path)
        except (ValueError, struct.error, IOError, OSError):
            continue
        text = LAUNCHER_TEMPLATE % {"cam": cam, "family": family_name(cam), "arch": arch, "interpreter": loader}
        if current == text:
            installed.append(cam)
        elif _write_atomic(target, text, 0o755):
            (created if current is None else updated).append(cam)
            installed.append(cam)
    try:
        names = os.listdir(scriptdir)
    except OSError:
        names = []
    for name in sorted(names):
        if not name.endswith("_cam.sh"):
            continue
        cam = name[:-7]
        if os.path.isfile(os.path.join(camdir, cam)):
            continue
        text = _read(os.path.join(scriptdir, name))
        if text is not None and MARKER in text:
            try:
                os.remove(os.path.join(scriptdir, name))
                removed.append(cam)
            except OSError as error:
                print(TAG, "Cannot remove", name, ":", error)
    write_cams_list(os.path.join(scriptdir, "altcam", "cams.list"), installed)
    for label, items in (("created", created), ("updated", updated), ("removed", removed)):
        if items:
            print(TAG, "Launchers %s: %s" % (label, ", ".join(items)))
    return created, updated, removed


def create_launchers(camdir, scriptdir):
    """Kept for callers that only need the names of the launchers that were created."""
    return sync_launchers(camdir, scriptdir)[0]


def main(argv):
    camdir = argv[1] if len(argv) > 1 else "/usr/bin"
    scriptdir = argv[2] if len(argv) > 2 else "/usr/camscript"
    created, updated, removed = sync_launchers(camdir, scriptdir)
    print(TAG, "launchers created: %d, updated: %d, removed: %d (cams in %s, scripts in %s)" % (
        len(created), len(updated), len(removed), camdir, scriptdir))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
