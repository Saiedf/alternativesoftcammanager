from __future__ import print_function
import os
import posixpath
import stat
import re
from Components.config import config, configfile
from .Compat import Command, to_text


def quote(value):
    """POSIX shell quoting, also available on Python 2.7."""
    return "'" + value.replace("'", "'\"'\"'") + "'"


def validcam(cam):
    return bool(cam and cam != "none" and not cam.startswith("-") and
                cam not in (".", "..") and "/" not in cam and
                "\\" not in cam and not any(ord(c) < 32 for c in cam))


def getcamscript(cam):
    cam = cam.lower()
    return cam.endswith(".sh") or cam.startswith(("softcam", "cardserver"))


def campath(cam):
    if not validcam(cam):
        raise ValueError("Invalid SoftCam name")
    return posixpath.join(config.plugins.AltSoftcam.camdir.value, cam)


def scriptpath(cam):
    if not validcam(cam):
        raise ValueError("Invalid SoftCam name")
    return posixpath.join(config.plugins.AltSoftcam.scriptdir.value, cam + "_cam.sh")


def support_paths():
    root = config.plugins.AltSoftcam.scriptdir.value
    return [posixpath.join(root, ".altcam", name) for name in ("control.sh", "cams.list")]


_launcher_cache = {}


def launcher_matches(cam):
    try:
        path = scriptpath(cam)
        info = os.stat(path)
        # The header is re-read only when the launcher file changes.
        key = (path, info.st_mtime, info.st_size)
        cached = _launcher_cache.get(path)
        if cached and cached[0] == key:
            return cached[1] == to_text(cam)
        with open(path, "rb") as handle:
            header = to_text(handle.read(4096))
        match = re.search(r"^CAM=['\"]([^'\"]+)['\"]\s*$", header, re.MULTILINE)
        _launcher_cache[path] = (key, match.group(1) if match else None)
        return bool(match and match.group(1) == to_text(cam))
    except (IOError, OSError, ValueError):
        return False


def preparecam(cam):
    if not stat.S_ISREG(os.stat(campath(cam)).st_mode):
        raise ValueError("SoftCam binary is not a regular file")
    if not launcher_matches(cam):
        raise ValueError("Missing or mismatched launcher: " + scriptpath(cam))
    for path in support_paths():
        if not os.path.isfile(path) or not os.access(path, os.R_OK):
            raise ValueError("Missing script support file: " + path)
    if not os.path.isdir(config.plugins.AltSoftcam.camconfig.value):
        raise ValueError("SoftCam configuration directory does not exist")


def _script_command(cam, action):
    # Passing settings explicitly also uses unsaved/new paths consistently.
    script = scriptpath(cam)
    if not launcher_matches(cam):
        raise ValueError("Missing or mismatched launcher: " + script)
    return ("ALT_SOFTCAM_BIN_DIR=%s ALT_SOFTCAM_CONFIG_DIR=%s /bin/sh %s %s" %
            (quote(config.plugins.AltSoftcam.camdir.value),
             quote(config.plugins.AltSoftcam.camconfig.value), quote(script), action))


def getcamcmd(cam):
    return _script_command(cam, "start")


def getstopcmd(cam):
    return _script_command(cam, "stop")


def getstatuscmd(cam):
    return _script_command(cam, "status")


def listcams():
    # Scan the small launcher directory, never every program in /usr/bin.
    if not all(os.path.isfile(path) for path in support_paths()):
        return []
    try:
        result = []
        for filename in os.listdir(config.plugins.AltSoftcam.scriptdir.value):
            if not filename.endswith("_cam.sh") or filename.startswith("."):
                continue
            cam = filename[:-7]
            if validcam(cam) and os.path.isfile(campath(cam)) and launcher_matches(cam):
                result.append(cam)
        return sorted(set(result))
    except OSError as error:
        print("[Alternative SoftCam Manager] Cannot list cams:", error)
        return []


# Legacy launcher names mapped to the current ones.
CAM_ALIASES = {"CCcam232": "CCcam_2.3.2", "CCcam238": "CCcam_2.3.8",
               "CCcam239": "CCcam_2.3.9", "Ncam_151": "Ncam_15.1",
               "OSCam11758-r801": "OSCam_11758-801",
               "OSCam_11758-r801": "OSCam_11758-801",
               "OSCam_11.572": "OSCam_11.572-r798",
               "oscam-emu_11868-802": "OSCam_11884-802"}


def normalize_cam(cam, available=None):
    if cam == "none":
        return cam
    available = listcams() if available is None else available
    if cam in available:
        return cam
    original = cam
    if cam.endswith("_cam.sh"):
        cam = cam[:-7]
    elif cam.endswith(".sh"):
        cam = cam[:-3]
    cam = CAM_ALIASES.get(cam, cam)
    matches = [name for name in available if name.lower() == cam.lower()]
    return matches[0] if len(matches) == 1 else original


def layout_errors():
    errors = []
    for key in ("camdir", "scriptdir", "camconfig"):
        value = getattr(config.plugins.AltSoftcam, key).value
        if not value or not os.path.isabs(value) or not os.path.isdir(value):
            errors.append(value or key)
    errors.extend(path for path in support_paths() if not os.path.isfile(path))
    return errors


def process_names(output):
    """Read executable columns instead of matching arbitrary ps arguments."""
    names = set()
    lines = output.splitlines()
    if not lines:
        raise ValueError("Empty ps output")
    header = lines[0].upper().split()
    index = None
    for field in ("COMMAND", "CMD", "ARGS"):
        if field in header:
            index = header.index(field)
            break
    if index is None:
        raise ValueError("Unsupported ps output")
    for line in lines[1:]:
        columns = line.split(None, index)
        if len(columns) <= index:
            continue
        command = columns[index].split()
        if command:
            names.add(os.path.basename(command[0]).strip("[]{}"))
            if command[0].startswith("{") and len(command) > 1:
                names.add(os.path.basename(command[1]))
            if os.path.basename(command[0]) in ("sh", "bash", "ash") and len(command) > 1:
                names.add(os.path.basename(command[1]))
    return names


def checkconfigdir():
    """Migrate standard legacy paths only when the installed package is present."""
    settings = config.plugins.AltSoftcam
    installed = os.path.isdir("/usr/bin") and os.path.isdir("/usr/camscript")
    if installed and settings.camdir.value in ("/var/emu", "/usr/camscript"):
        if settings.camdir.value == "/usr/camscript":
            settings.scriptdir.value = "/usr/camscript"
            settings.scriptdir.save()
        settings.camdir.value = "/usr/bin"
        settings.camdir.save()
    if settings.camconfig.value == "/var/keys" and os.path.isdir("/etc/tuxbox/config"):
        has_keys_config = any(os.path.isfile(posixpath.join("/var/keys", name))
                              for name in ("oscam.conf", "ncam.conf", "CCcam.cfg"))
        if not has_keys_config:
            settings.camconfig.value = "/etc/tuxbox/config"
            settings.camconfig.save()
    active = normalize_cam(settings.actcam.value)
    if active != settings.actcam.value:
        settings.actcam.value = active
        settings.actcam.save()
    return not layout_errors()


class CamController(object):
    """Serialize operations across autostart, screen and extensions menu."""
    def __init__(self):
        self.command = None
        self.busy = False
        self.callback = None
        self.progress = None
        self.target = "none"
        self.current = "none"

    def change(self, current, target, callback=None, progress=None):
        if self.busy:
            return False
        available = listcams()
        current = normalize_cam(current, available)
        target = normalize_cam(target, available)
        try:
            if target != "none":
                preparecam(target)
            stopcmd = getstopcmd(current) if current != "none" else None
        except (OSError, ValueError) as error:
            if callback:
                callback(False, current, str(error))
            return True
        self.busy = True
        self.callback = callback
        self.progress = progress
        self.current, self.target = current, target
        if self.command is None:
            self.command = Command()
        if stopcmd:
            self._progress("stop", current)
            self.command.run(stopcmd, self._stopped)
        else:
            self._stopped("", 0)
        return True

    def _progress(self, stage, cam):
        if self.progress is not None:
            self.progress(stage, cam)

    def _stopped(self, output, retval):
        if retval:
            self._finish(False, output or "SoftCam stop failed")
            return
        self.current = "none"
        if self.target == "none":
            self._finish(True, "")
        else:
            self._progress("start", self.target)
            try:
                command = getcamcmd(self.target)
            except ValueError as error:
                self._finish(False, str(error))
                return
            self.command.run(command, self._started)

    def _started(self, output, retval):
        if retval:
            self._finish(False, output or "SoftCam start failed")
        else:
            self._progress("verify", self.target)
            try:
                command = getstatuscmd(self.target)
            except ValueError as error:
                self._finish(False, str(error))
                return
            self.command.run(command, self._verified, timeout=5000)

    def _verified(self, output, retval):
        success = retval == 0 and bool(output.strip())
        if success:
            self.current = self.target
        self._finish(success, "" if success else "SoftCam exited without a running process")

    def _finish(self, success, message):
        self.busy = False
        self.progress = None
        setting = config.plugins.AltSoftcam.actcam
        setting.value = self.current
        setting.save()
        try:
            configfile.save()
        except (IOError, OSError) as error:
            print("[Alternative SoftCam Manager] Cannot save config:", error)
        callback, self.callback = self.callback, None
        if callback:
            callback(success, self.current, message[:2048])
        elif not success:
            print("[Alternative SoftCam Manager]", message)

    def shutdown(self):
        if self.command is not None:
            self.command.close()
        self.command = None
        self.busy = False
        self.callback = None
        self.progress = None


controller = CamController()
