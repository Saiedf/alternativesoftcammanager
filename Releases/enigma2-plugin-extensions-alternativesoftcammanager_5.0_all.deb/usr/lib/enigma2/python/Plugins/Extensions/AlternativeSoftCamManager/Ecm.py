"""Read the ECM information file written by the running softcam."""
from __future__ import print_function
import os
import stat
import time
from .Compat import to_text

# Different cams write different file names; the newest readable one wins.
ECM_FILES = ("/tmp/ecm.info", "/tmp/ecm0.info", "/tmp/ecm1.info")
MAX_BYTES = 8192
MAX_LINES = 24
STALE_SECONDS = 120


def _newest_file():
    best = None
    for path in ECM_FILES:
        try:
            info = os.stat(path)
        except OSError:
            continue
        # Regular files only: a FIFO or device could block the GUI thread.
        if not stat.S_ISREG(info.st_mode) or info.st_size == 0:
            continue
        if best is None or info.st_mtime > best[1]:
            best = (path, info.st_mtime)
    return best


def clean_text(raw):
    """Make cam output safe for a Label: no NULs, tabs or carriage returns."""
    text = to_text(raw)
    if not isinstance(text, type(u"")):
        text = text.decode("utf-8", "replace")
    text = text.replace(u"\x00", u"").replace(u"\r", u"").replace(u"\t", u"    ")
    lines = [line.rstrip() for line in text.split(u"\n")]
    while lines and not lines[-1]:
        lines.pop()
    return u"\n".join(lines[:MAX_LINES])


def read_ecm_info():
    """Return the current ECM text, or an empty string when there is none."""
    found = _newest_file()
    if found is None:
        return u""
    path, mtime = found
    if time.time() - mtime > STALE_SECONDS:
        return u""
    try:
        with open(path, "rb") as handle:
            return clean_text(handle.read(MAX_BYTES))
    except (IOError, OSError):
        return u""
