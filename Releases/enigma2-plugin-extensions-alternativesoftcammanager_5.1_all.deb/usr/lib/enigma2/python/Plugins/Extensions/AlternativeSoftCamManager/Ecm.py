"""Read and present the ECM information file written by the running softcam."""
from __future__ import print_function
import os
import stat
import time
from .Compat import to_text

# Different cams write different file names; the newest readable one wins.
ECM_FILES = ("/tmp/ecm.info", "/tmp/ecm0.info", "/tmp/ecm1.info")
MAX_BYTES = 8192
MAX_LINES = 24
STALE_SECONDS = 60

# (label, keys the various cams use for it); the first key found wins.
FIELDS = (
    ("System", ("system", "caid system")),
    ("CAID", ("caid", "CAID")),
    ("Provider", ("provider", "prov", "provid", "Provider")),
    ("PID", ("pid", "ECM PID")),
    ("Reader", ("reader", "source", "decode", "using")),
    ("From", ("from", "address")),
    ("Protocol", ("protocol",)),
    ("Hops", ("hops",)),
    ("ECM time", ("ecm time", "response time", "response")),
)


def _newest_file():
    best = None
    for path in ECM_FILES:
        try:
            info = os.stat(path)
        except OSError:
            continue
        # Regular files only: a FIFO or device could block the GUI thread.
        if not stat.S_ISREG(info.st_mode) or info.st_size == 0:
            continue
        if best is None or info.st_mtime > best[1]:
            best = (path, info.st_mtime)
    return best


def clean_text(raw):
    """Make cam output safe for a Label: no NULs, tabs or carriage returns."""
    text = to_text(raw)
    if not isinstance(text, type(u"")):
        text = text.decode("utf-8", "replace")
    text = text.replace(u"\x00", u"").replace(u"\r", u"").replace(u"\t", u"    ")
    lines = [line.rstrip() for line in text.split(u"\n")]
    while lines and not lines[-1]:
        lines.pop()
    return u"\n".join(lines[:MAX_LINES])


def parse_ecm(text):
    """Turn 'key: value' lines into a dict; other lines are ignored."""
    info = {}
    for line in text.split(u"\n"):
        key, sep, value = line.partition(u":")
        if sep and key.strip() and value.strip() and key.strip() not in info:
            info[key.strip()] = value.strip()
    return info


def format_ecm(text):
    """Readable summary of an ECM file; the raw text when no known field exists."""
    info = parse_ecm(text)
    if not info:
        return text
    using = info.get(u"using", u"").lower()
    lines = []
    if using == u"fta":
        lines.append(u"FTA (free to air)")
    for label, keys in FIELDS:
        for key in keys:
            value = info.get(key)
            if value:
                if label == "Reader" and using == u"fta":
                    break
                lines.append(u"%s: %s" % (label, value))
                break
    return u"\n".join(lines) if lines else text


def read_ecm_info(cam_running=None):
    """Return (text, state): state is 'fresh', 'stale', 'missing' or 'idle'.

    The text is empty for 'missing' and 'idle'; the caller decides the wording.
    """
    found = _newest_file()
    if found is None:
        return u"", ("missing" if cam_running else "idle")
    path, mtime = found
    try:
        with open(path, "rb") as handle:
            text = format_ecm(clean_text(handle.read(MAX_BYTES)))
    except (IOError, OSError):
        return u"", "missing"
    age = int(time.time() - mtime)
    # A clock that jumped (time sync after boot) gives huge or negative ages; treat as fresh.
    return text, ("stale" if STALE_SECONDS < age < 10 * 365 * 86400 else "fresh")
