from __future__ import print_function
from os.path import dirname, join
from Components.config import config, ConfigSubsection, ConfigText, ConfigYesNo
from Plugins.Plugin import PluginDescriptor
from . import _, svg_support, VERSION
from .Compat import Command, Timer, ui_text
from .Softcam import controller, checkconfigdir, process_names, validcam


# Preserve existing config objects if Enigma2 reloads the module.
if not hasattr(config.plugins, "AltSoftcam"):
    config.plugins.AltSoftcam = ConfigSubsection()
for key, factory in (
        ("actcam", lambda: ConfigText(default="none")),
        ("camconfig", lambda: ConfigText(default="/etc/tuxbox/config", visible_width=100, fixed_size=False)),
        ("camdir", lambda: ConfigText(default="/usr/bin", visible_width=100, fixed_size=False)),
        ("scriptdir", lambda: ConfigText(default="/usr/camscript", visible_width=100, fixed_size=False)),
        ("showinextensions", lambda: ConfigYesNo(default=True)),
        ("restartext", lambda: ConfigYesNo(default=True))):
    if not hasattr(config.plugins.AltSoftcam, key):
        setattr(config.plugins.AltSoftcam, key, factory())


class StartCamOnStart(object):
    def __init__(self):
        # Importing or enumerating the plugin never starts timers/processes.
        self.Timer = None
        self.command = None
        self.enabled = False

    def start(self):
        self.enabled = True
        if self.Timer is None:
            self.Timer = Timer(self.camnotrun)
        self.Timer.start(2000)

    def stop(self):
        self.enabled = False
        if self.Timer is not None:
            self.Timer.close()
            self.Timer = None
        if self.command is not None:
            self.command.close()
            self.command = None

    def camnotrun(self):
        if not self.enabled or controller.busy:
            return
        if not checkconfigdir():
            print("[Alternative SoftCam Manager] Check binary, script and configuration paths in Setup")
            return
        cam = config.plugins.AltSoftcam.actcam.value
        if not validcam(cam):
            return
        if self.command is None:
            self.command = Command()
        self.command.run("ps", self.checkprocess, timeout=5000)

    def checkprocess(self, result, retval):
        if not self.enabled or retval or controller.busy:
            return
        try:
            names = process_names(result)
        except ValueError as error:
            print("[Alternative SoftCam Manager] Autostart skipped:", error)
            return
        cam = config.plugins.AltSoftcam.actcam.value
        known = ("oscam", "ncam", "mgcamd", "wicard", "camd3", "mcas", "cccam",
                 "gbox", "mpcs", "mbox", "newcs", "vizcam", "rucam")
        if cam in names or any(name.lower().startswith(known) for name in names):
            return
        if validcam(cam) and checkconfigdir():
            controller.change("none", cam)


startcamonstart = StartCamOnStart()
EnigmaStart = False


def main(session, **kwargs):
    from .Manager import AltCamManager
    session.open(AltCamManager)


def restartcam(session, **kwargs):
    from Screens.MessageBox import MessageBox
    if not checkconfigdir():
        session.open(MessageBox, _("Check binary, script and configuration paths in Setup"), type=MessageBox.TYPE_ERROR, timeout=5)
        return
    cam = config.plugins.AltSoftcam.actcam.value
    if not validcam(cam):
        return
    # A manual operation supersedes a delayed autostart check.
    startcamonstart.stop()

    def completed(success, current, message):
        text = (_("SoftCam restarted successfully: %s") % cam) if success else message
        session.open(MessageBox, ui_text(text), type=MessageBox.TYPE_INFO if success else MessageBox.TYPE_ERROR, timeout=5)

    if not controller.change(cam, cam, completed):
        session.open(MessageBox, _("SoftCam operation already in progress"), type=MessageBox.TYPE_INFO, timeout=3)


def stop_cam_blocking(cam, limit=4.0):
    import subprocess
    import time
    from .Softcam import getstopcmd
    try:
        process = subprocess.Popen(getstopcmd(cam), shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    except (OSError, ValueError) as error:
        print("[Alternative SoftCam Manager] Shutdown stop failed:", error)
        return False
    deadline = time.time() + limit
    while process.poll() is None and time.time() < deadline:
        time.sleep(0.05)
    if process.poll() is None:
        process.kill()
        process.wait()
        print("[Alternative SoftCam Manager] Shutdown stop timed out")
        return False
    process.stdout.close()
    return process.returncode == 0


def startcam(reason, **kwargs):
    global EnigmaStart
    if reason == 0 and not EnigmaStart:
        EnigmaStart = True
        if validcam(config.plugins.AltSoftcam.actcam.value):
            startcamonstart.start()
    elif reason == 1:
        EnigmaStart = False
        startcamonstart.stop()
        # Invalidate in-flight callbacks before scheduling the shutdown stop.
        controller.shutdown()
        cam = config.plugins.AltSoftcam.actcam.value
        if validcam(cam):
            # The mainloop may exit before an async stop finishes, so stop here with a hard limit.
            # The configured cam stays saved and starts again on next boot.
            stop_cam_blocking(cam)


def manager_descriptor(where):
    name = _("Alternative SoftCam Manager")
    if VERSION:
        name += " " + VERSION
    return PluginDescriptor(
        name=name,
        description=_("Start, stop, restart SoftCams, change settings."),
        where=[where],
        icon=join(dirname(__file__), "images", "softcam.%s" % ("svg" if svg_support else "png")), fnc=main)


def restart_descriptor():
    return PluginDescriptor(name=_("Restart softcam"),
                            where=[PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=restartcam)


def update_extensions_menu():
    # Update only our menu entries; never reload the autostart descriptor.
    try:
        from Components.config import configfile
        configfile.save()
    except ImportError:
        pass
    try:
        from Components.PluginComponent import plugins
    except ImportError:
        return False
    where = PluginDescriptor.WHERE_EXTENSIONSMENU
    try:
        for callback, enabled in ((main, config.plugins.AltSoftcam.showinextensions.value),
                                  (restartcam, config.plugins.AltSoftcam.restartext.value)):
            found = [item for item in plugins.getPlugins(where)
                     if getattr(item, "fnc", None) is callback and getattr(item, "where", None) == [where]]
            for item in found[1 if enabled else 0:]:
                plugins.removePlugin(item)
            if enabled and not found:
                plugins.addPlugin(manager_descriptor(where) if callback is main else restart_descriptor())
    except Exception as error:
        print("[Alternative SoftCam Manager] Cannot update extensions menu:", error)
        return False
    return True


def Plugins(**kwargs):
    result = [manager_descriptor(PluginDescriptor.WHERE_PLUGINMENU),
              PluginDescriptor(where=PluginDescriptor.WHERE_AUTOSTART, needsRestart=True, fnc=startcam)]
    if config.plugins.AltSoftcam.showinextensions.value:
        result.append(manager_descriptor(PluginDescriptor.WHERE_EXTENSIONSMENU))
    if config.plugins.AltSoftcam.restartext.value:
        result.append(restart_descriptor())
    return result
