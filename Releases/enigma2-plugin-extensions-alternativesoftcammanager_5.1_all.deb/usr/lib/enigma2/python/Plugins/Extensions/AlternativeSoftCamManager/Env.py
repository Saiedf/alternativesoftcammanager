"""Runtime environment detection: Python generation and image family."""
from __future__ import print_function
import os
import sys

PY2 = sys.version_info[0] == 2
PY3 = not PY2

# DreamOS images are dpkg based; the open-source images use opkg.
# The dpkg status file is the reliable marker.
IS_DREAMOS = os.path.exists("/var/lib/dpkg/status")
IS_OPEN_IMAGE = not IS_DREAMOS


def has_command(name):
    for folder in os.environ.get("PATH", "/usr/bin:/bin:/usr/sbin:/sbin").split(os.pathsep):
        path = os.path.join(folder, name)
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return True
    return False


def package_manager():
    if IS_DREAMOS and has_command("dpkg"):
        return "dpkg"
    if has_command("opkg"):
        return "opkg"
    return "dpkg" if has_command("dpkg") else "unknown"


def describe():
    """One line for crash logs: which branch of the code is running."""
    return "image=%s python=%d.%d packages=%s" % (
        "dreamos" if IS_DREAMOS else "open", sys.version_info[0], sys.version_info[1], package_manager())
