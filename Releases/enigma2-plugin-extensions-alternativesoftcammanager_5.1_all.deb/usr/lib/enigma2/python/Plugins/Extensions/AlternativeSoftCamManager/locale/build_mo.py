#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Pure-Python PO compiler for AlternativeSoftCamManager.

Compiles all .po files in the locale directory into binary .mo files
without requiring gettext tools (msgfmt) to be installed.
"""
from __future__ import print_function
import io
import os
import re
import struct
import sys


def parse_po(file_path):
    """Parse a gettext .po file into a dictionary of {msgid: msgstr}."""
    catalog = {}
    msgid = None
    msgstr = None
    in_msgid = False
    in_msgstr = False

    with io.open(file_path, "r", encoding="utf-8-sig") as fp:
        for line in fp:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            if line.startswith('msgid "'):
                if msgid is not None and msgstr is not None:
                    catalog[msgid] = msgstr
                msgid = line[7:-1].encode("utf-8").decode("unicode_escape")
                msgstr = None
                in_msgid = True
                in_msgstr = False
            elif line.startswith('msgstr "'):
                msgstr = line[8:-1].encode("utf-8").decode("unicode_escape")
                in_msgid = False
                in_msgstr = True
            elif line.startswith('"') and line.endswith('"'):
                content = line[1:-1].encode("utf-8").decode("unicode_escape")
                if in_msgid:
                    msgid += content
                elif in_msgstr:
                    msgstr += content

    if msgid is not None and msgstr is not None:
        catalog[msgid] = msgstr

    return catalog


def generate_mo(catalog):
    """Compile a translations catalog dict into GNU MO binary bytes."""
    items = [(k, v) for k, v in catalog.items() if v]
    if "" not in catalog:
        header = (
            "Project-Id-Version: AlternativeSoftCamManager 5.0\n"
            "MIME-Version: 1.0\n"
            "Content-Type: text/plain; charset=UTF-8\n"
            "Content-Transfer-Encoding: 8bit\n"
        )
        items.insert(0, ("", header))
    items.sort(key=lambda x: x[0])

    count = len(items)
    orig_table_offset = 28
    trans_table_offset = 28 + count * 8
    strings_offset = trans_table_offset + count * 8

    orig_bytes = [k.encode("utf-8") + b"\x00" for k, v in items]
    trans_bytes = [v.encode("utf-8") + b"\x00" for k, v in items]

    orig_indices = []
    curr = strings_offset
    for b in orig_bytes:
        orig_indices.append((len(b) - 1, curr))
        curr += len(b)

    trans_indices = []
    for b in trans_bytes:
        trans_indices.append((len(b) - 1, curr))
        curr += len(b)

    output = bytearray()
    output.extend(
        struct.pack("<7I", 0x950412DE, 0, count, orig_table_offset, trans_table_offset, 0, 0)
    )
    for l, o in orig_indices:
        output.extend(struct.pack("<2I", l, o))
    for l, o in trans_indices:
        output.extend(struct.pack("<2I", l, o))
    for b in orig_bytes:
        output.extend(b)
    for b in trans_bytes:
        output.extend(b)
    return bytes(output)


def compile_all():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    compiled = 0

    for item in sorted(os.listdir(base_dir)):
        lang_path = os.path.join(base_dir, item)
        po_path = None
        mo_dir = None

        if os.path.isdir(lang_path) and not item.startswith("."):
            candidate_po = os.path.join(lang_path, "LC_MESSAGES", "AlternativeSoftCamManager.po")
            if os.path.isfile(candidate_po):
                po_path = candidate_po
                mo_dir = os.path.join(lang_path, "LC_MESSAGES")
            else:
                candidate_root_po = os.path.join(base_dir, item + ".po")
                if os.path.isfile(candidate_root_po):
                    po_path = candidate_root_po
                    mo_dir = os.path.join(lang_path, "LC_MESSAGES")

        if po_path and mo_dir:
            os.makedirs(mo_dir, exist_ok=True)
            catalog = parse_po(po_path)
            mo_path = os.path.join(mo_dir, "AlternativeSoftCamManager.mo")
            with open(mo_path, "wb") as fp:
                fp.write(generate_mo(catalog))
            valid_entries = len([k for k in catalog.keys() if k])
            print("Compiled [{0}]: {1} ({2} strings)".format(item, mo_path, valid_entries))
            compiled += 1

    print("\nCompleted: {0} language files compiled successfully.".format(compiled))


if __name__ == "__main__":
    compile_all()
