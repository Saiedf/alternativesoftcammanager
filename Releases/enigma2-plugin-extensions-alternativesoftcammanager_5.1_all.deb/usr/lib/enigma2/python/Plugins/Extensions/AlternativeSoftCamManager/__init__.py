from os import environ
from os.path import dirname, join
import io
import sys
from gettext import bindtextdomain, dgettext, gettext

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS


def read_version():
	try:
		with io.open(join(dirname(__file__), "ver.txt"), "r", encoding="utf-8-sig") as version_file:
			version = version_file.readline(128).strip()
			return version.encode("utf-8") if sys.version_info[0] == 2 else version
	except (IOError, OSError, UnicodeError):
		return ""


VERSION = read_version()


def localeInit():
	lang = language.getLanguage()[:2] if language.getLanguage() else "en"
	environ["LANGUAGE"] = lang
	bindtextdomain("AlternativeSoftCamManager", resolveFilename(SCOPE_PLUGINS,
			"Extensions/AlternativeSoftCamManager/locale"))


def _(txt):
	if not txt:
		return ""
	t = dgettext("AlternativeSoftCamManager", txt)
	if t == txt:
		t = gettext(txt)
	return t


localeInit()
language.addCallback(localeInit)


try:
	# Check functions for full svg and scaling support
	from enigma import loadSVG  # noqa: F401
	from skin import applySkinFactor  # noqa: F401
	svg_support = True
except ImportError:
	svg_support = False
