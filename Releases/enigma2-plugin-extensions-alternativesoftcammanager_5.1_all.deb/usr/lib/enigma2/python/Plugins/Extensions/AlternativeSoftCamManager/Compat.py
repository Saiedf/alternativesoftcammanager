"""Python 2.7/3 and Enigma2 capability adapters."""
from __future__ import print_function
import sys
from enigma import eTimer
from Components.Console import Console


def to_text(value):
    return value.decode("utf-8", "replace") if isinstance(value, bytes) else value


def ui_text(value):
    """DreamOS/Python 2 native widgets expect UTF-8 byte strings."""
    value = to_text(value)
    return value.encode("utf-8") if sys.version_info[0] == 2 else value


class Timer(object):
    def __init__(self, callback):
        self.timer = eTimer()
        self.callback = callback
        self.connection = None
        self.callbacks = None
        # Open images provide a list; DreamOS provides a native signal.
        if hasattr(self.timer, "callback"):
            self.callbacks = self.timer.callback
        elif hasattr(self.timer.timeout, "callback"):
            self.callbacks = self.timer.timeout.callback
        if self.callbacks is not None:
            self.callbacks.append(self._fire)
        else:
            signal = self.timer.timeout
            if not hasattr(signal, "connect"):
                signal = signal.get()
            self.connection = signal.connect(self._fire)

    def _fire(self):
        # Dropped once closed, so a signal that cannot be disconnected stays harmless.
        callback = self.callback
        if callback is not None:
            callback()

    def start(self, delay, single=True):
        self.timer.start(delay, single)

    def stop(self):
        self.timer.stop()

    def close(self):
        self.stop()
        self.callback = None
        if self.callbacks is not None and self._fire in self.callbacks:
            self.callbacks.remove(self._fire)
        if self.connection is not None and hasattr(self.connection, "disconnect"):
            self.connection.disconnect()
        self.connection = None


class Command(object):
    """An asynchronous command with deadline and stale callback protection."""
    def __init__(self):
        try:
            self.console = Console(binary=True)
        except TypeError:  # Legacy DreamOS.
            self.console = Console()
        self.timer = Timer(self._timeout)
        self.callback = None
        self.generation = 0

    def run(self, command, callback, timeout=15000):
        if self.callback is not None:
            return False
        self.generation += 1
        generation = self.generation
        self.callback = callback
        self.timer.start(timeout)
        try:
            # Some images synchronously waitpid() if no callback is supplied.
            self.console.ePopen(ui_text(command), self._done, generation)
        except Exception as error:
            self._done(str(error), -1, generation)
        return True

    def _done(self, output, retval, generation):
        if generation != self.generation or self.callback is None:
            return
        self.timer.stop()
        callback, self.callback = self.callback, None
        callback(to_text(output), retval)

    def _kill(self):
        for name in list(self.console.appContainers):
            try:
                self.console.kill(name)
            except (KeyError, RuntimeError):
                pass

    def _timeout(self):
        callback, self.callback = self.callback, None
        self.generation += 1
        self._kill()
        if callback is not None:
            callback("Command timed out", -1)

    def close(self):
        self.callback = None
        self.generation += 1
        self.timer.close()
        self._kill()
