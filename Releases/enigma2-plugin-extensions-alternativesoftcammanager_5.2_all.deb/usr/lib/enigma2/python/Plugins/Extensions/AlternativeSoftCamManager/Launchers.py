"""Creates the per-cam launchers and the cam list on the receiver itself.

This module has no Enigma2 dependency. It is used in two places:
  * the plugin imports create_launchers() when it starts or opens;
  * the package post-install script runs it directly, so the launchers already exist
    in the script folder right after the installation:
        python Launchers.py [cam folder] [script folder]
Python 2.7 and 3 compatible.
"""
from __future__ import print_function
import os
import struct
import sys

FAMILY_PREFIXES = ("oscam", "ncam", "cccam")
NOT_A_CAM = (".conf", ".cfg", ".txt", ".bak", ".old", ".tmp", ".log", ".list", ".xml", ".sh",
             ".py", ".pyc", ".so", ".key", ".server", ".user")
TAG = "[Alternative SoftCam Manager]"

LAUNCHER_TEMPLATE = """#!/bin/sh
# Launcher for the adjacent bin package.
OSD='%(cam)s'
CAM='%(cam)s'
CAM_FAMILY='%(family)s'
CAM_ARCH='%(arch)s'
CAM_INTERPRETER='%(interpreter)s'
SCRIPT_DIR=$(CDPATH= cd -P "$(dirname "$0")" && pwd) || exit 1
if [ ! -r "$SCRIPT_DIR/altcam/control.sh" ]; then
    echo "Missing altcam/control.sh; install the entire camscript directory" >&2
    exit 1
fi
. "$SCRIPT_DIR/altcam/control.sh"
"""


def _text(value):
    return value.decode("utf-8", "replace") if isinstance(value, bytes) else value


def family_name(cam):
    """oscam, ncam or cccam judged from the binary name, else None."""
    lowered = cam.lower()
    for prefix in FAMILY_PREFIXES:
        if lowered.startswith(prefix):
            return prefix
    return None


def valid_name(cam):
    """Plain file-name characters only: the name ends up in paths and shell commands."""
    return bool(cam) and not cam.startswith(("-", ".")) and \
        all(ch.isalnum() or ch in "._+-" for ch in cam)


def is_cam_name(cam):
    return valid_name(cam) and family_name(cam) is not None and not cam.lower().endswith(NOT_A_CAM)


def elf_info(path):
    """(arch, loader) read from the ELF header of a cam binary: arch is arm32, arm64 or native."""
    with open(path, "rb") as handle:
        head = handle.read(4096)
        data = bytearray(head)
        if data[:4] != bytearray(b"\x7fELF"):
            raise ValueError("not an ELF binary")
        is64 = data[4] == 2
        end = "<" if data[5] == 1 else ">"
        machine = struct.unpack(end + "H", bytes(head[18:20]))[0]
        if is64:
            phoff = struct.unpack(end + "Q", bytes(head[32:40]))[0]
            phentsize, phnum = struct.unpack(end + "HH", bytes(head[54:58]))
        else:
            phoff = struct.unpack(end + "I", bytes(head[28:32]))[0]
            phentsize, phnum = struct.unpack(end + "HH", bytes(head[42:46]))
        loader = ""
        for index in range(min(phnum, 64)):
            handle.seek(phoff + index * phentsize)
            entry = handle.read(56 if is64 else 32)
            if is64:
                kind, _flags, off, _va, _pa, size = struct.unpack(end + "IIQQQQ", bytes(entry[:40]))
            else:
                kind, off, _va, _pa, size = struct.unpack(end + "IIIII", bytes(entry[:20]))
            if kind == 3 and 0 < size < 256:  # PT_INTERP: the dynamic loader path
                handle.seek(off)
                loader = _text(handle.read(size).split(b"\0")[0])
    return {40: "arm32", 183: "arm64"}.get(machine, "native"), loader


def _write_atomic(path, text, mode):
    temporary = path + ".tmp"
    try:
        with open(temporary, "wb") as handle:
            handle.write(text.encode("utf-8"))
        os.chmod(temporary, mode)
        # os.replace (Python 3) also overwrites on Windows; on Linux rename is already atomic.
        getattr(os, "replace", os.rename)(temporary, path)
        return True
    except (IOError, OSError) as error:
        print(TAG, "Cannot write", path, ":", error)
        try:
            os.remove(temporary)
        except OSError:
            pass
        return False


def write_cams_list(path, names):
    """Write the installed cams, one per line, replacing the file only when its content changes."""
    text = "".join(name + "\n" for name in names)
    try:
        with open(path, "rb") as handle:
            if _text(handle.read()) == text:
                return
    except (IOError, OSError):
        pass
    _write_atomic(path, text, 0o644)


def create_launchers(camdir, scriptdir):
    """Create <cam>_cam.sh in scriptdir for every cam binary in camdir that has none, and write
    scriptdir/altcam/cams.list with the cams installed on this receiver.

    A launcher that already exists is never changed. Returns the names that were created.
    """
    created = []
    if not os.path.isfile(os.path.join(scriptdir, "altcam", "control.sh")) or not os.path.isdir(camdir):
        return created
    installed = []
    for cam in sorted(os.listdir(camdir), key=lambda name: name.lower()):
        path = os.path.join(camdir, cam)
        if not (is_cam_name(cam) and os.path.isfile(path)):
            continue
        target = os.path.join(scriptdir, cam + "_cam.sh")
        if os.path.exists(target):
            installed.append(cam)
            continue
        try:
            arch, loader = elf_info(path)
        except (ValueError, struct.error, IOError, OSError):
            continue
        text = LAUNCHER_TEMPLATE % {"cam": cam, "family": family_name(cam), "arch": arch, "interpreter": loader}
        if _write_atomic(target, text, 0o755):
            created.append(cam)
            installed.append(cam)
    write_cams_list(os.path.join(scriptdir, "altcam", "cams.list"), installed)
    if created:
        print(TAG, "Created launchers:", ", ".join(created))
    return created


def main(argv):
    camdir = argv[1] if len(argv) > 1 else "/usr/bin"
    scriptdir = argv[2] if len(argv) > 2 else "/usr/camscript"
    created = create_launchers(camdir, scriptdir)
    print(TAG, "launchers created: %d (cams in %s, scripts in %s)" % (len(created), camdir, scriptdir))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
