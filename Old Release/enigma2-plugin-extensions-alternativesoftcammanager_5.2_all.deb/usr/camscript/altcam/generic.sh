#!/bin/sh
# Generic launcher: runs any oscam / ncam / cccam binary that has no <name>_cam.sh of its own.
# Usage: sh generic.sh <binary name> <start|stop|restart|status>
# The cam family comes from the binary name, so only the binary has to be copied to the bin folder.

CAM=${1-}
if [ -z "$CAM" ]; then
    echo "Usage: generic.sh <binary name> <start|stop|restart|status>" >&2
    exit 2
fi
shift

# The name ends up in paths and commands: allow plain file-name characters only.
case "$CAM" in
    *[!A-Za-z0-9._+-]*|-*|.|..) echo "$CAM: invalid cam name" >&2; exit 2 ;;
esac

lower=$(printf '%s' "$CAM" | tr 'A-Z' 'a-z')
case "$lower" in
    oscam*) CAM_FAMILY=oscam ;;
    ncam*) CAM_FAMILY=ncam ;;
    cccam*) CAM_FAMILY=cccam ;;
    *) echo "$CAM: unsupported cam name (it must start with oscam, ncam or cccam)" >&2; exit 2 ;;
esac

# Architecture is not guessed from the name; the system itself is the reference.
CAM_ARCH=native
CAM_INTERPRETER=''
OSD=$CAM
SCRIPT_DIR=$(CDPATH= cd -P "$(dirname "$0")/.." && pwd) || exit 1
if [ ! -r "$SCRIPT_DIR/altcam/control.sh" ]; then
    echo "Missing altcam/control.sh; install the entire camscript directory" >&2
    exit 1
fi
. "$SCRIPT_DIR/altcam/control.sh"
