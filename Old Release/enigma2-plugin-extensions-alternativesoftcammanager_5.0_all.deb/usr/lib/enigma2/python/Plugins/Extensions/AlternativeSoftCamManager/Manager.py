from __future__ import print_function

import os


from enigma import getDesktop

from Components.ActionMap import ActionMap
from Components.config import config, getConfigListEntry
from Components.ConfigList import ConfigListScreen
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.Label import Label
from Components.Sources.List import List
from Components.Sources.StaticText import StaticText
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from Tools.LoadPixmap import LoadPixmap

from . import _, svg_support, VERSION
from .Compat import Command, Timer, to_text, ui_text
from .Ecm import read_ecm_info
from .Softcam import checkconfigdir, getstatuscmd, layout_errors, listcams, normalize_cam, process_names, controller


def manager_layout(desktop_width, desktop_height, vector=False):
    # Match the reference enlargement; constrain the result for smaller desktops.
    density = max(0.8, desktop_height / 720.0) if vector else 1.0
    base_width, base_height = (820, 660) if vector else (780, 630)
    width = min(int(base_width * density), int(desktop_width - 40 * density))
    scale = float(width) / base_width
    px = lambda value: max(1, int(round(value * scale)))
    # The window frame is drawn by this skin (wfNoBorder) so the title is controllable.
    title_height = px(46)
    height = min(int(base_height * density) + title_height, int(desktop_height - 90 * density))
    margin, gap, side = px(12), px(10), px(20)
    top = title_height + margin
    inner = width - 2 * side
    button_height, operation_height, progress_height = px(46), px(30), px(10)
    progress_y = height - side - px(12) - progress_height
    operation_y = progress_y - gap - operation_height
    button_y = operation_y - gap - button_height
    list_width = int(inner * 0.55)
    ecm_x = side + list_width + 2 * gap
    ecm_width = width - side - ecm_x
    row_height = px(66)
    # Fill the whole area down to the buttons: fit whole rows by adjusting row height.
    available = max(button_y - gap - top, row_height)
    rows = max(1, available // row_height)
    row_height = available // rows
    list_height = available
    icon_sizes = ((51, 40), (64, 50), (96, 75), (128, 100), (192, 150))
    icon_width, icon_height = icon_sizes[0]
    for candidate in icon_sizes:
        if candidate[0] <= px(64):
            icon_width, icon_height = candidate
    icon_x, icon_y = px(6), (row_height - icon_height) // 2
    name_x = icon_x + icon_width + px(14)
    name_width = list_width - name_x - px(12)
    name_font = max(10, px(30 if vector else 32) - 2)
    family_font = px(14)
    template = ('{"template": ['
        'MultiContentEntryText(pos=(%d,%d),size=(%d,%d),font=0,flags=RT_HALIGN_LEFT,text=0),'
        'MultiContentEntryPixmapAlphaTest(pos=(%d,%d),size=(%d,%d),png=1),'
        'MultiContentEntryText(pos=(%d,%d),size=(%d,%d),font=1,flags=RT_HALIGN_CENTER,text=2)],'
        '"fonts":[gFont("Regular",%d),gFont("Regular",%d)],"itemHeight":%d}' %
        (name_x,px(6),name_width,row_height-px(12),icon_x,icon_y,icon_width,icon_height,
         icon_x,icon_y+int(icon_height*0.62),icon_width,int(icon_height*0.38),
         name_font,family_font,row_height))
    # Flat dark theme. Enigma2 paints eLabel items above named widgets, so no
    # decorative eLabel may overlap a widget: every panel is either a widget
    # with its own background or an eLabel placed beside/above it.
    bg, card, button_bg = "#14181f", "#1c222b", "#262e3a"
    text_color, muted, accent = "#e8edf2", "#8a94a3", "#29b6f6"
    border, select = "#1b3b52", "#24516b"
    strip, pad, header_height = px(4), px(12), px(40)
    ecm_card_x = ecm_x - gap
    ecm_card_width = width - side - ecm_card_x
    status_y = top + header_height + px(2)

    def label(x, y, w, h, color):
        return '<eLabel position="%d,%d" size="%d,%d" backgroundColor="%s"/>' % (x, y, w, h, color)

    parts = ['<screen name="AlternativeSoftCamManagerProgress" position="center,center" size="%d,%d" backgroundColor="%s" flags="wfNoBorder">' % (width, height, bg),
        # Own header: title starts at the far left, 2pt smaller than the window-frame title.
        label(0, 0, px(10), title_height, border),
        '<widget name="title" position="%d,0" size="%d,%d" font="Regular;%d" valign="center" halign="left" foregroundColor="#f5a623" backgroundColor="%s"/>' % (
            px(10), width - px(10), title_height, px(24), border),
        label(0, title_height, width, px(3), accent),
        # 20px side/bottom border below the header.
        label(0, title_height + px(3), side, height - title_height - px(3), border),
        label(width - side, title_height + px(3), side, height - title_height - px(3), border),
        label(0, height - side, width, side, border),
        # Softcam list (own background, no panel behind it).
        '<widget source="list" render="Listbox" position="%d,%d" size="%d,%d" enableWrapAround="1" scrollbarMode="showOnDemand" backgroundColor="%s" backgroundColorSelected="%s" foregroundColor="%s"><convert type="TemplatedMultiContent">%s</convert></widget>' % (
            side, top, list_width, list_height, card, select, text_color, template),
        # ECM panel built from non-overlapping pieces: header, left padding, status widget.
        '<eLabel text="Ecm info" halign="center" valign="center" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s"/>' % (
            ecm_card_x, top, ecm_card_width, header_height, px(26), accent, card),
        label(ecm_card_x, top + header_height, ecm_card_width, px(2), button_bg),
        label(ecm_card_x, status_y, pad, list_height - header_height - px(2), card),
        '<widget name="status" position="%d,%d" size="%d,%d" font="Regular;%d" foregroundColor="%s" backgroundColor="%s"/>' % (
            ecm_card_x + pad, status_y, ecm_card_width - pad, list_height - header_height - px(2), px(20), text_color, card)]
    button_width = (inner - 3 * gap) // 4
    for index, (key, color) in enumerate((("red", "#e53935"), ("green", "#43a047"), ("yellow", "#f9a825"), ("blue", "#1e88e5"))):
        x = side + index * (button_width + gap)
        parts.append('<widget source="key_%s" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" halign="center" valign="center" foregroundColor="%s" backgroundColor="%s"/>' % (
            key, x, button_y, button_width, button_height - strip, px(26), text_color, button_bg))
        parts.append(label(x, button_y + button_height - strip, button_width, strip, color))
    hint_width = px(155)
    parts.extend([
        '<widget name="operation" position="%d,%d" size="%d,%d" font="Regular;%d" valign="center" foregroundColor="%s" backgroundColor="%s"/>' % (
            side, operation_y, inner - hint_width - gap, operation_height, px(20), text_color, bg),
        '<widget source="key_menu" render="Label" position="%d,%d" size="%d,%d" font="Regular;%d" halign="right" valign="center" foregroundColor="%s" backgroundColor="%s"/>' % (
            width - side - hint_width, operation_y, hint_width, operation_height, px(18), muted, bg),
        '<widget name="progress" position="%d,%d" size="%d,%d" foregroundColor="%s" backgroundColor="%s"/>' % (
            side, progress_y, inner, progress_height, accent, button_bg),
        '</screen>'])
    return "".join(parts), (icon_width, icon_height)


def load_manager_icon(name, size):
    root = "Extensions/AlternativeSoftCamManager/images/"
    if svg_support:
        path = resolveFilename(SCOPE_PLUGINS, root + name + ".svg")
        try:
            pixmap = LoadPixmap(path, width=size[0], height=size[1])
            if pixmap is not None:
                return pixmap
        except TypeError:
            pass  # Old LoadPixmap: use an already-sized PNG, no scaling API needed.
    suffix = "" if size == (51,40) else "_%dx%d" % size
    return LoadPixmap(resolveFilename(SCOPE_PLUGINS, root + name + suffix + ".png"))


def about_layout(desktop_width, desktop_height, vector=False):
    """Skin for the About screen, in the same flat theme as the manager."""
    density = max(0.8, desktop_height / 720.0) if vector else 1.0
    base_width, base_height = 620, 420
    width = min(int(base_width * density), int(desktop_width - 40 * density))
    scale = float(width) / base_width
    px = lambda value: max(1, int(round(value * scale)))
    title_height, side, margin = px(46), px(20), px(12)
    height = min(int(base_height * density), int(desktop_height - 90 * density))
    bg, border, accent = "#14181f", "#1b3b52", "#29b6f6"
    text_color, muted = "#e8edf2", "#8a94a3"
    inner = width - 2 * side
    top = title_height + px(3) + margin
    foot_y = height - side - px(34)
    paths_y = top + px(48) + px(92) + px(10)

    def label(x, y, w, h, color):
        return '<eLabel position="%d,%d" size="%d,%d" backgroundColor="%s"/>' % (x, y, w, h, color)

    def text(name, x, y, w, h, size, color, halign):
        return '<widget name="%s" position="%d,%d" size="%d,%d" font="Regular;%d" halign="%s" valign="center" foregroundColor="%s" backgroundColor="%s"/>' % (
            name, x, y, w, h, size, halign, color, bg)

    return "".join([
        '<screen name="AlternativeSoftCamManagerAbout" position="center,center" size="%d,%d" backgroundColor="%s" flags="wfNoBorder">' % (width, height, bg),
        label(0, 0, px(10), title_height, border),
        text("title", px(10), 0, width - px(10), title_height, px(24), "#f5a623", "left").replace('backgroundColor="%s"' % bg, 'backgroundColor="%s"' % border),
        label(0, title_height, width, px(3), accent),
        label(0, title_height + px(3), side, height - title_height - px(3), border),
        label(width - side, title_height + px(3), side, height - title_height - px(3), border),
        label(0, height - side, width, side, border),
        text("name", side, top, inner, px(44), px(30), accent, "center"),
        text("info", side, top + px(48), inner, px(92), px(22), text_color, "center"),
        label(side + px(40), paths_y - px(5), inner - px(80), px(1), border),
        text("paths", side + px(10), paths_y, inner - px(20), foot_y - paths_y - px(4), px(18), muted, "left"),
        text("hint", side, foot_y, inner, px(30), px(18), muted, "center"),
        '</screen>'])


class AboutScreen(Screen):
    def __init__(self, session):
        size = getDesktop(0).size()
        self.skin = about_layout(size.width(), size.height(), svg_support)
        Screen.__init__(self, session)
        self.skinName = "AlternativeSoftCamManagerAbout"
        self.title = ui_text(_("About"))
        self["title"] = Label(self.title)
        self["name"] = Label(ui_text(u"Alternative SoftCam Manager"))
        info = u"Developer :  Taapat\nModified By :  iet5"
        if VERSION:
            info += u"\nVersion :  " + to_text(VERSION)
        self["info"] = Label(ui_text(info))
        paths = to_text(_("Start, stop and restart CCcam, NCam and OSCam."))
        for label, key in ((_("Binaries"), "camdir"), (_("Scripts"), "scriptdir"), (_("Configuration"), "camconfig")):
            paths += u"\n" + to_text(label) + u": " + to_text(getattr(config.plugins.AltSoftcam, key).value)
        self["paths"] = Label(ui_text(paths))
        self["hint"] = Label(ui_text(u"OK / EXIT"))
        self["actions"] = ActionMap(["OkCancelActions"], {"ok": self.close, "cancel": self.close})


class AltCamManager(Screen):

    def __init__(self, session):
        size = getDesktop(0).size()
        self.skin, icon_size = manager_layout(size.width(), size.height(), svg_support)
        Screen.__init__(self, session)
        # Older theme definitions named AltCamManager have no progress widgets.
        self.skinName = "AlternativeSoftCamManagerProgress"
        self.title = ui_text(u"SoftCam Manger \u2013 Modified by iet5" +
                (u" \u2013 V " + to_text(VERSION) if VERSION else u""))
        self.command = Command()
        self.closed = False
        self.refreshing = False
        self.finish = True
        self.iscam = False
        self.softcamlist = []
        self.ecm_text = None
        self.layout_error = None
        self.operation_active = False
        self.operation_action = None
        self.operation_cam = None
        self.settings_dialog = None
        self.refresh_timer = None
        self.refresh_saved = False
        self.message_timer = None
        self.pending_message = None
        self.onClose.append(self.cleanup)
        self["key_red"] = StaticText(_("Stop"))
        self["key_green"] = StaticText(_("Start"))
        self["key_yellow"] = StaticText(_("Restart"))
        self["key_blue"] = StaticText(_("Setup"))
        self["key_menu"] = StaticText(_("MENU: Options"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "MovieSelectionActions", "MenuActions"], {
                "cancel": self.cancel,
                "ok": self.ok,
                "green": self.start,
                "red": self.stop,
                "yellow": self.restart,
                "blue": self.setup,
                "menu": self.options,
                "contextMenu": self.options})
        self["title"] = Label(self.title)
        self["status"] = Label()
        self["operation"] = Label(_("Ready"))
        self["progress"] = ProgressBar()
        self["progress"].setValue(0)
        self["list"] = List([])
        checkconfigdir()
        self.actcam = config.plugins.AltSoftcam.actcam.value
        self.actcampng = load_manager_icon("actcam", icon_size)
        self.defcampng = load_manager_icon("defcam", icon_size)
        self.Timer = Timer(self.listecminfo)
        self.Timer.start(2000, False)
        self.onLayoutFinish.append(self.createinfo)

    def cleanup(self):
        self.closed = True
        timer = getattr(self, "Timer", None)
        if timer is not None:
            timer.close()
        if self.refresh_timer is not None:
            self.refresh_timer.close()
            self.refresh_timer = None
        if self.message_timer is not None:
            self.message_timer.close()
            self.message_timer = None
        self.command.close()
        if controller.callback == self.operation_done:
            controller.callback = None
        if controller.progress == self.operation_progress:
            controller.progress = None
        self.settings_dialog = None

    def listecminfo(self):
        if self.closed:
            return
        # Independent of the detected cam: any fresh ECM file is shown.
        text = read_ecm_info() or _("Waiting for ECM data...")
        if text != self.ecm_text:
            self.ecm_text = text
            self["status"].setText(ui_text(text))

    def createinfo(self, retval=None, notify=True):
        if self.closed or self.refreshing or controller.busy:
            return
        self.actcam = config.plugins.AltSoftcam.actcam.value
        self.softcamlist = listcams()
        self.actcam = normalize_cam(self.actcam, self.softcamlist)
        self.iscam = bool(self.softcamlist)
        self.listecminfo()
        if not self.softcamlist:
            errors = layout_errors()
            message = (_("Missing or invalid SoftCam paths:\n%s") % "\n".join(errors)) if errors else _("No matching binary and launcher pairs found")
            if message != self.layout_error and notify:
                self.layout_error = message
                # createinfo can run while the skin is applied, before this screen is modal.
                # Some images refuse session.open() then, so the dialog is shown after layout.
                self.pending_message = message
                if self.message_timer is None:
                    self.message_timer = Timer(self.show_pending_message)
                self.message_timer.start(400)
            self.createcamlist()
            return
        self.layout_error = None
        self.refreshing = True
        self.finish = False
        self.command.run("ps", self.camactive, timeout=5000)

    def show_pending_message(self):
        message, self.pending_message = self.pending_message, None
        if message and not self.closed:
            self.session.open(MessageBox, ui_text(message), type=MessageBox.TYPE_ERROR, timeout=6)

    def camactive(self, result, retval, extra_args=None):
        if self.closed:
            return
        self.refreshing = False
        if retval == 0:
            try:
                names = process_names(result)
            except ValueError:
                names = None
            if names is not None:
                running = [cam for cam in self.softcamlist if cam in names]
                if self.actcam in self.softcamlist and self.actcam not in running:
                    # Some ps variants truncate names; use the launcher's native status.
                    self.detected_running = running
                    try:
                        command = getstatuscmd(self.actcam)
                    except ValueError:
                        pass
                    else:
                        self.refreshing = True
                        self.command.run(command, self.camstatus, timeout=5000)
                        return
                self.actcam = self.actcam if self.actcam in running else (running[0] if running else "none")
        self.createcamlist()

    def camstatus(self, result, retval):
        if self.closed:
            return
        self.refreshing = False
        if retval == 3:
            self.actcam = self.detected_running[0] if self.detected_running else "none"
        self.createcamlist()

    def createcamlist(self):
        if self.closed:
            return
        camlist = []
        if self.actcam in self.softcamlist:
            camlist.append((self.actcam, self.actcampng, self.checkcam(self.actcam)))
        for cam in self.softcamlist:
            if cam != self.actcam:
                camlist.append((cam, self.defcampng, self.checkcam(cam)))
        self["list"].list = camlist
        self.finish = True

    def checkcam(self, cam):
        cam = cam.title()
        if cam.startswith("Ncam"):
            return "NCam"
        if cam[:5] in ("Oscam", "Camd3", "Newcs", "Rucam"):
            return cam[:5]
        elif cam[:4] in ("Mcas", "Gbox", "Mpcs", "Mbox"):
            return cam[:4]
        cam = cam[:6]
        if "Cccam" in cam:
            return "CCcam"
        else:
            return cam

    def notice(self, message, error=False):
        if not self.closed:
            if not error and (self.operation_active or controller.busy):
                self["operation"].setText(ui_text(message))
                return
            self.session.open(MessageBox, ui_text(message),
                type=MessageBox.TYPE_ERROR if error else MessageBox.TYPE_INFO, timeout=4)

    def ready(self):
        if self.closed:
            return False
        if controller.busy or self.operation_active:
            self.notice(_("SoftCam operation already in progress. Please wait."))
            return False
        if not self.finish:
            self.notice(_("SoftCam list is updating. Please wait."))
            return False
        return True

    def change(self, target, action=None):
        if not self.ready():
            return
        from .plugin import startcamonstart
        startcamonstart.stop()
        self.operation_action = action or ("stop" if target == "none" else "start")
        self.operation_cam = self.actcam if target == "none" else target
        self.operation_active = True
        self["operation"].setText(ui_text(_("Preparing %s...") % self.operation_cam))
        self["progress"].setValue(5)
        self.finish = False
        if not controller.change(self.actcam, target, self.operation_done, self.operation_progress):
            self.finish = True
            self.operation_active = False
            self["progress"].setValue(0)
            self["operation"].setText(ui_text(_("SoftCam operation already in progress")))
            self.notice(_("SoftCam operation already in progress. Please wait."))

    def operation_progress(self, stage, cam):
        if self.closed:
            return
        text, value = {
            "stop": (_("Stopping %s..."), 20),
            "start": (_("Starting %s..."), 55),
            "verify": (_("Checking %s..."), 85)}[stage]
        self["operation"].setText(ui_text(text % cam))
        self["progress"].setValue(value)

    def operation_done(self, success, current, message):
        if self.closed:
            return
        self.actcam = current
        self.finish = True
        self.operation_active = False
        cam = self.operation_cam or current
        if success:
            text = {
                "start": _("SoftCam started successfully: %s"),
                "restart": _("SoftCam restarted successfully: %s"),
                "stop": _("SoftCam stopped successfully: %s")}[self.operation_action or "start"] % cam
            self["operation"].setText(ui_text(text))
            self["progress"].setValue(100)
            self.notice(text)
        else:
            text = _("SoftCam operation failed: %s") % cam
            self["operation"].setText(ui_text(text))
            self["progress"].setValue(0)
            self.notice(to_text(text) + "\n" + to_text(message), error=True)
        self.createinfo(notify=success)

    def start(self):
        if not self.ready():
            return
        current = self["list"].getCurrent()
        if not current:
            self.notice(_("No SoftCam selected. Check the binary and script paths in Setup."))
        elif current[0] == self.actcam:
            self.notice(_("%s is already running") % self.actcam)
        else:
            self.change(current[0], "start")

    def stop(self):
        if not self.ready():
            return
        if self.actcam == "none":
            self.notice(_("No SoftCam is running"))
        else:
            self.change("none", "stop")

    def restart(self):
        if not self.ready():
            return
        if self.actcam == "none":
            self.notice(_("No SoftCam is running. Press Start first."))
        else:
            self.change(self.actcam, "restart")

    def ok(self):
        if not self.ready():
            return
        current = self["list"].getCurrent()
        if current:
            if current[0] == self.actcam:
                self.restart()
            else:
                self.start()
        else:
            self.notice(_("No SoftCam selected. Check the binary and script paths in Setup."))

    def cancel(self):
        # An operation can finish safely without keeping this screen open.
        if not controller.busy:
            config.plugins.AltSoftcam.actcam.value = self.actcam
            config.plugins.AltSoftcam.save()
        self.close()

    def options(self):
        if not self.ready():
            return
        state = _("Yes") if config.plugins.AltSoftcam.showinextensions.value else _("No")
        self.session.openWithCallback(self.option_selected, ChoiceBox, title=_("Options"), list=[
            (_("Show plugin in blue-button menu: %s") % state, "visibility"),
            (_("About the program"), "about"),
            (_("Setup"), "setup")])

    def option_selected(self, choice):
        if self.closed or not choice:
            return
        if choice[1] == "visibility":
            from .plugin import update_extensions_menu
            setting = config.plugins.AltSoftcam.showinextensions
            setting.value = not setting.value
            setting.save()
            updated = update_extensions_menu()
            text = (_("Plugin shown in blue-button menu") if setting.value else _("Plugin hidden from blue-button menu"))
            if not updated:
                text += "\n" + _("Restart the Enigma2 interface to apply this setting")
            self.notice(text)
        elif choice[1] == "about":
            self.session.open(AboutScreen)
        elif choice[1] == "setup":
            self.setup()

    def setup(self):
        if self.ready():
            self.settings_dialog = self.session.openWithCallback(self.settings_closed, ConfigEdit)

    def settings_closed(self, *args):
        if self.closed:
            return
        saved = bool(args and args[0] is True)
        self.settings_dialog = None
        if saved:
            self["operation"].setText(ui_text(_("Settings saved successfully")))
        # Let the screen transition finish before disk writes and process scans.
        if self.refresh_timer is None:
            self.refresh_timer = Timer(self.deferred_refresh)
        self.refresh_saved = saved
        self.refresh_timer.start(400)

    def deferred_refresh(self):
        if self.closed:
            return
        if self.refresh_saved:
            from .plugin import update_extensions_menu
            update_extensions_menu()
        self.createinfo()
        if self.refresh_saved:
            self["operation"].setText(ui_text(_("Settings saved successfully")))


class ConfigEdit(ConfigListScreen, Screen):
    def __init__(self, session):
        Screen.__init__(self, session)
        self.closing = False
        self.title = ui_text(_("SoftCam path configuration"))
        self.skinName = ["ConfigEdit", "Setup"]
        self["key_red"] = StaticText(_("Exit"))
        self["key_green"] = StaticText(_("Ok"))
        self["about"] = StaticText(_("Configure SoftCam binaries, scripts and configuration paths"))
        self["HelpWindow"] = Pixmap()
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
                "cancel": self.keyCancel,
                "red": self.keyCancel,
                "ok": self.ok,
                "green": self.ok}, -2)
        ConfigListScreen.__init__(self, [], session=session)
        self["config"].list = [getConfigListEntry(_("SoftCam config directory"),
                config.plugins.AltSoftcam.camconfig),
            getConfigListEntry(_("SoftCam directory"),
                config.plugins.AltSoftcam.camdir),
            getConfigListEntry(_("SoftCam script directory"),
                config.plugins.AltSoftcam.scriptdir),
            getConfigListEntry(_("Show 'Restart softcam' in extensions menu"),
                config.plugins.AltSoftcam.restartext)]

    def ok(self):
        if self.closing:
            return
        missing = []
        normalized = []
        for setting in (config.plugins.AltSoftcam.camconfig, config.plugins.AltSoftcam.camdir, config.plugins.AltSoftcam.scriptdir):
            path = os.path.normpath(setting.value.strip()) if setting.value.strip() else ""
            if not path or not os.path.isabs(path) or not os.path.isdir(path):
                missing.append(setting.value)
            elif path != setting.value:
                normalized.append((setting, path))
        if not missing:
            for setting, path in normalized:
                setting.value = path
            missing = layout_errors()
        if not missing:
            self.closing = True
            config.plugins.AltSoftcam.save()
            self.close(True)
        else:
            self.session.open(MessageBox,
                _("Directory %s does not exist!\nPlease set the correct directory path!") % ", ".join(missing),
                type=MessageBox.TYPE_ERROR, timeout=5)
